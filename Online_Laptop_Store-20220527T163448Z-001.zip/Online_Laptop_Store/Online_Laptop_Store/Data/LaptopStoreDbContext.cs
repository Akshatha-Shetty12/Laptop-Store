﻿using Microsoft.EntityFrameworkCore;
using Online_Laptop_Store.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Online_Laptop_Store.Data
{
    public class LaptopStoreDbContext: DbContext
    {
        public LaptopStoreDbContext()
        {

        }
        public LaptopStoreDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Laptop> Laptops { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Orders> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Orders>().HasOne(b => b.Laptops)
                .WithMany(ba => ba.Orders)
                .HasForeignKey(bi => bi.LaptopId);

            


        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
            //base.OnConfiguring(optionsBuilder);
        }
    }
}
