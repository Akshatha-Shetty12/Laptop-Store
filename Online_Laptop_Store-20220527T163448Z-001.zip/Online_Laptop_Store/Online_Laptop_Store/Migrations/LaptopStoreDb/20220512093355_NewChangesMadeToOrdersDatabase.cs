﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Online_Laptop_Store.Migrations.LaptopStoreDb
{
    public partial class NewChangesMadeToOrdersDatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
